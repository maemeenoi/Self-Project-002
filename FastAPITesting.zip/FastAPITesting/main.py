from fastapi import FastAPI, UploadFile
from azure.storage.blob import BlobServiceClient
import httpx, os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = FastAPI()

# Connect to Azure Blob Storage
connection_string = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
container_name = os.getenv("AZURE_BLOB_CONTAINER", "staging")

blob_service_client = BlobServiceClient.from_connection_string(connection_string)
container_client = blob_service_client.get_container_client(container_name)


@app.post("/fetch-and-save")
async def fetch_and_save():
    """Fetch from GitHub API and save JSON into staging blob."""
    async with httpx.AsyncClient() as client:
        response = await client.get("https://api.github.com/repos/tiangolo/fastapi")
        data = response.json()

    blob_name = "fastapi_repo_info.json"
    container_client.upload_blob(name=blob_name, data=str(data), overwrite=True)

    return {"message": f"Saved {blob_name} in {container_name}"}


@app.post("/upload-file/")
async def upload_file(file: UploadFile):
    """Upload a file from client to blob container."""
    blob_name = file.filename
    container_client.upload_blob(name=blob_name, data=await file.read(), overwrite=True)
    return {"message": f"Uploaded {blob_name} to {container_name}"}